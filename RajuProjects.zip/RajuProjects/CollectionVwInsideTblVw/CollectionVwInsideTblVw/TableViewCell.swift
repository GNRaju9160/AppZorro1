//
//  TableViewCell.swift
//  CollectionVwInsideTblVw
//
//  Created by Appzorro on 31/12/19.
//  Copyright © 2019 Appzorro. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
