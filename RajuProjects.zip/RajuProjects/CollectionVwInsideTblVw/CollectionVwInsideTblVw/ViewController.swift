
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!

    
    
    let arrFlowers = [#imageLiteral(resourceName: "images-34"),#imageLiteral(resourceName: "images-36"),#imageLiteral(resourceName: "images-35"),#imageLiteral(resourceName: "images-37"),#imageLiteral(resourceName: "images-33")]
    let arrAnimals = [#imageLiteral(resourceName: "images-41"),#imageLiteral(resourceName: "images-38"),#imageLiteral(resourceName: "images-44"),#imageLiteral(resourceName: "images-39"),#imageLiteral(resourceName: "images-40")]
    let arrtollywood = [#imageLiteral(resourceName: "7"),#imageLiteral(resourceName: "13"),#imageLiteral(resourceName: "11"),#imageLiteral(resourceName: "12"),#imageLiteral(resourceName: "14")]
    
    var arrSelected = [UIImage]()
    
    var arrSelectedItems = [5,5,5]
    
  var refreshControl = UIRefreshControl()

    override func viewDidLoad() {
        super.viewDidLoad()
       

        refreshControl = UIRefreshControl()
        
        refreshControl.backgroundColor = UIColor.red
        refreshControl.tintColor = UIColor.yellow
        
        tableView.addSubview(refreshControl)

     
        }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell") as! TableViewCell
        
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        guard let tableViewCell = cell as? TableViewCell else { return }
        
        self.setCollectionViewDataSourceDelegate(collectionView:tableViewCell.collectionView,dataSourceDelegate: self, forRow: indexPath.row)
    }
}
extension ViewController: UICollectionViewDataSource,UICollectionViewDelegate {
    
    func setCollectionViewDataSourceDelegate(collectionView:UICollectionView,dataSourceDelegate: UICollectionViewDataSource & UICollectionViewDelegate, forRow row: Int) {
        collectionView.delegate = dataSourceDelegate
        collectionView.dataSource = dataSourceDelegate
        collectionView.tag = row
        collectionView.reloadData()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView.tag{
        case 0:
            return arrFlowers.count
        case 1:
            return arrAnimals.count
            
        default:
            return arrtollywood.count
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        switch collectionView.tag{
        case 0:
            cell.imgView.image = arrFlowers[indexPath.item]
        case 1:
            cell.imgView.image = arrAnimals[indexPath.item]
            
        default:
            cell.imgView.image = arrtollywood[indexPath.item]
        }
        cell.imgSelected.isHidden = arrSelectedItems[collectionView.tag] != indexPath.item
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "XIBViewController") as! XIBViewController
        self.navigationController?.pushViewController(nextVC, animated: true)
        
        if arrSelectedItems[collectionView.tag] == indexPath.item {
            
            arrSelectedItems[collectionView.tag] = 5
        }else{
            arrSelectedItems[collectionView.tag] = indexPath.item
        }
        tableView.reloadData()
        }

    
    
    
}
