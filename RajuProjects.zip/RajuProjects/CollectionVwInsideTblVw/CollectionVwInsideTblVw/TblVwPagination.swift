//
//  TblVwPagination.swift
//  CollectionVwInsideTblVw
//
//  Created by appzorro on 1/14/20.
//  Copyright © 2020 Appzorro. All rights reserved.
//

import UIKit

class TblVwPagination: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
    
    @IBOutlet weak var tblvwList: UITableView!
    var recordsArray:[Int] = Array()
    
    override func viewDidLoad() {
        super.viewDidLoad()

       tblvwList.delegate = self
        tblvwList.dataSource = self
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        <#code#>
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        <#code#>
    }
}
