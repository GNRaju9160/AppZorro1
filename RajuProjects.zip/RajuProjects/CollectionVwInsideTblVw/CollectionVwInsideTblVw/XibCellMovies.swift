
import UIKit

class XibCellMovies: UITableViewCell {
    @IBOutlet weak var imgVwMovies: UIImageView!
    @IBOutlet weak var lblMovieName: UILabel!
    @IBOutlet weak var lblMovieHero: UILabel!
    @IBOutlet weak var imgSelectedMovies: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
