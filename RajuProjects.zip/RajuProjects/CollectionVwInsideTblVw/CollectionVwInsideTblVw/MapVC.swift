//
//  MapVC.swift
//  CollectionVwInsideTblVw
//
//  Created by Appzorro on 08/01/20.
//  Copyright © 2020 Appzorro. All rights reserved.
//

import UIKit
import MapKit
class MapVC: UIViewController {
    @IBOutlet weak var mkMap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       let location = CLLocationCoordinate2DMake(30.709703, 76.693658)
        let span = MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2)
        let region = MKCoordinateRegion(center: location, span: span)
        mkMap.setRegion(region, animated: true)
//        mkMap.setRegion(region, animated: true)
        
        let droppin = MKPointAnnotation()
        droppin.coordinate = location
        droppin.title = "Appzorro"
        droppin.subtitle = "IOS"
        mkMap.addAnnotation(droppin)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
