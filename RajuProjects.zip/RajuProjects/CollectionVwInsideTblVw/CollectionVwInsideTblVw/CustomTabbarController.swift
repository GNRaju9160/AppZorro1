
import UIKit

class CustomTabbarController: UIViewController {
    
    var tabBarcont = UITabBarController()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        createTabBarController()
    }
    
    func createTabBarController() {
        tabBarcont = UITabBarController()
        tabBarcont.tabBar.barStyle = .blackOpaque
        
        
        let firstViewController = UIViewController()
    //   firstViewController.title = [#imageLiteral(resourceName: "home")]
        firstViewController.title = "First"
        
        firstViewController.view.backgroundColor = .red
        
        let secondViewController = UIViewController()
       // secondViewController.title = [#imageLiteral(resourceName: "settings")]
        secondViewController.title = "Second"
        secondViewController.view.backgroundColor = .blue
        
        let thirdViewController = UIViewController()
      //  thirdViewController.title = [#imageLiteral(resourceName: "History")]
        thirdViewController.title = "Third"
        thirdViewController.view.backgroundColor = .yellow
        
        tabBarcont.viewControllers = [firstViewController, secondViewController, thirdViewController]
        self.view.addSubview(tabBarcont.view)
        
    }
   
}
