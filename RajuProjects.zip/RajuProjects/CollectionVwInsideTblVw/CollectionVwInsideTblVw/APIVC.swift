
import UIKit

class APIVC: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var tblVwList: UITableView!
    
    var arrUsers = [userModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let parameters = ["title": "Raju", "body": "Appzorro"]
        
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return }
        var request = URLRequest(url: url)
        //   request.httpMethod = "GET"
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else { return }
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
            }
            
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    self.arrUsers.append(userModel(json as! [String : Any]))
                    DispatchQueue.main.async {
                        self.tblVwList.reloadData()
                    }
                }catch {
                    print(error)
                  
                }
            } }.resume()
    }
    class userModel {
        var id, title, body : String!
        
        init(_ detils : [String:Any]) {
            id = detils["id"] as? String ?? ""
            title = detils["title"] as? String ?? ""
            body = detils["body"] as? String ?? ""
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUsers.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "APITvc") as! APITvc
        let details = arrUsers[indexPath.row]
        
        cell.lblId.text = details.id
        cell.lblTitle.text = details.title
        cell.lblBody.text = details.body
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
        
    }
}

//  https://jsonplaceholder.typicode.com/posts
//  https://jsonplaceholder.typicode.com/todos/1
//  https://learnappmaking.com/ex/users.json
