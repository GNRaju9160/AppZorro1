
import UIKit

class XIBViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tblVw: UITableView!
    
    let arrPlayers = ["Dhoni","Virat","KL Rahul","Prudvi Shah","Yuvaraj","Dinesh Karthik","Bhumrah","Sachin"]
    var arrImages = [#imageLiteral(resourceName: "Dhoni"),#imageLiteral(resourceName: "Virat"),#imageLiteral(resourceName: "KL Rahul"),#imageLiteral(resourceName: "Prudvi Shah"),#imageLiteral(resourceName: "YUvaraj"),#imageLiteral(resourceName: "Dinesh Karthik"),#imageLiteral(resourceName: "Bhumrah"),#imageLiteral(resourceName: "Sachin")]
    var arrMovies = [#imageLiteral(resourceName: "7"),#imageLiteral(resourceName: "5-1"),#imageLiteral(resourceName: "14"),#imageLiteral(resourceName: "3"),#imageLiteral(resourceName: "10"),#imageLiteral(resourceName: "12"),#imageLiteral(resourceName: "15"),#imageLiteral(resourceName: "6")]
    let arrMovieNames = ["Bahubali","Lagaan","Mahanati","Pad Man","Padmavathi","Guna 369","Majili","S D millionaire"]
    let arrHeros = ["Prabhas","Amir Khan","Keerthi suresh","Akshay kumar","Deepika padukune","Karthikeya","Chaithanya","Jamal malik"]
    let arrHeaderTitles = ["Players", "Movies"]
  
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let nib = UINib.init(nibName: "XibCell", bundle: nil)
        self.tblVw.register(nib, forCellReuseIdentifier: "XibCell")
        
        let nib2 = UINib.init(nibName: "XibCellMovies", bundle: nil)
        self.tblVw.register(nib2, forCellReuseIdentifier: "XibCellMovies")
        
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return arrImages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "XibCell") as! XibCell
            
            cell.lblNames.text = arrPlayers[indexPath.row]
            cell.imgVw.image = arrImages[indexPath.row]
            cell.imgSelectedPlayers.isHidden = true
            
            return cell
        }else{
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "XibCellMovies") as! XibCellMovies
            
            cell2.imgVwMovies.image = arrMovies[indexPath.row]
            cell2.lblMovieName.text = arrMovieNames[indexPath.row]
            cell2.lblMovieHero.text = arrHeros[indexPath.row]
            cell2.imgSelectedMovies.isHidden = true
            return cell2
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section < arrHeaderTitles.count {
            return arrHeaderTitles[section]
        }
        return nil
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 70
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            tableView.deselectRow(at: indexPath, animated: true)
        
            if let cell = tableView.cellForRow(at: indexPath as IndexPath) {
                if cell.accessoryType == .checkmark{
                   cell.accessoryType = .none
                }
                else{
                    cell.accessoryType = .checkmark
                }
            }
}
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            self.arrImages.remove(at: indexPath.row)
            self.tblVw.reloadData()
}
    }
}
//        switch indexPath.section {
//        case 0:
//            if editingStyle == .delete{
//                self.arrImages.remove(at: indexPath.row)
//
//        default:
//            if editingStyle == .delete{
//             self.arrMovies.remove(at: indexPath.row)
//        }
//
//        self.tblVw.reloadData()
//       
//        }
// }

//        tblVw.cellForRow(at: indexPath as IndexPath)?.accessoryType = .checkmark
//    }
//    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
//        tblVw.cellForRow(at: indexPath as IndexPath)?.accessoryType = .none
//        }

//        if let cell = tableView.cellForRow(at: indexPath) {
//            cell.accessoryType = .none
