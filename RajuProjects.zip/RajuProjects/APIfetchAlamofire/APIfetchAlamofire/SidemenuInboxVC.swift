//
//  SidemenuInboxVC.swift
//  APIfetchAlamofire
//
//  Created by appzorro on 1/13/20.
//  Copyright © 2020 Appzorro. All rights reserved.
//

import UIKit

class SidemenuInboxVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   
}
