

import UIKit
//import Alamofire


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    
    @IBOutlet weak var tblVw: UITableView!
    var arrUsers = [Users]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let parameters = ["firstname": "", "lastname": "", "age": ""]
       let api = URL(string: "https://learnappmaking.com/ex/users.json")!
        let session = URLSession.shared
        var request = URLRequest(url: api)
        request.httpMethod = "GET"
        guard  let httpBody = try? JSONSerialization.data(withJSONObject:  parameters, options: []) else {return}
            request.httpBody = httpBody
        
        session.dataTask(with: request) { (data, response, error) in
            if let response = response {
                print(response)
        }
            if let data = data {
    
        }
        do{
            let json = try JSONSerialization.jsonObject(with: data!, options: []) as! [[String:Any]]
            for i in json
            {
                self.arrUsers.append(Users((i as? [String : Any])!))
            }
            DispatchQueue.main.async {
                self.tblVw.reloadData()
            }
        }catch {
            print(error)
        }
    }.resume()
   }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return arrUsers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "APITVc") as! APITVc
    
       cell.lblFirstName.text = arrUsers[indexPath.row].firstname
        cell.lblLastName.text = arrUsers[indexPath.row].lastname
        cell.lblAge.text = "\(arrUsers[indexPath.row].age)"
       
        return cell
}
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 180
        
    }
    

}
