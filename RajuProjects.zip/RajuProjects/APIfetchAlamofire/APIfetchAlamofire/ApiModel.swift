
import Foundation

class Users {
    var firstname = String()
    var lastname = String()
    var age = Int()
    
    init(_ data :[String: Any]) {
        firstname  = data["first_name"] as? String ?? "No Data"
        lastname  = data["last_name"] as? String ?? "No Data"
        age  = data["age"] as? Int ?? 0
    
    }
}
