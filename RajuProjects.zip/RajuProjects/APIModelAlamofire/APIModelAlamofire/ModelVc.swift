import Foundation
import UIKit

class Details {
    var username = String()
    var notification = String()
    var profile_pic = String()
    
   
    
    init (_ data :[String: Any]) {
        profile_pic = data["profile_pic"] as? String ?? ""
        username = data["username"] as? String ?? "No Data"
        notification = data["notification"] as? String ?? "No Data"

    }
}
