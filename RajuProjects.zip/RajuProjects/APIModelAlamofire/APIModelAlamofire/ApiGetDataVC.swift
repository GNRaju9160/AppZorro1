
import UIKit
import Alamofire

class ApiGetDataVC: UIViewController {
    
    @IBOutlet weak var tblVw: UITableView!
    var arrData = [ModelData]()
    let urlString = "https://rawuncensored.com/api.php"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myApi()
    }
    func myApi() {
        let parameters: Parameters = ["action": "follow_list", "user_id": "1", "user_type": "1", "pageNo": "1"]
        Alamofire.request(urlString, method: .get, parameters: parameters).responseJSON { response in
            if var resp = response.result.value as? [String : Any],var respData = resp["response"] as? [String: Any],var data = respData["data"] as? [String: Any],let dataM = data["detail"] as? [[String:Any]] {
                for i in dataM {
                   let datar = ModelData(i)
                    self.arrData.append(datar)
                }
                DispatchQueue.main.async {
                    self.tblVw.reloadData()
                }}}}}
extension ApiGetDataVC : UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ApiGetDataCell") as! ApiGetDataCell
        let cellData : ModelData
        cellData = arrData[indexPath.row]
        cell.lblUserId.text = cellData.use_Id
        cell.lblUserName.text = cellData.userName
        cell.lblFullName.text = cellData.fullName
        cell.lblUserType.text = cellData.userType
        if let imgprofileUrl = URL(string:cellData.profilepic){
        cell.imgVwProfile.loadn(url:imgprofileUrl)//.image = data.profile_pic
    }
        cell.imgVwProfile.layer.borderWidth = 1.0
        cell.imgVwProfile.layer.borderColor = UIColor.red.cgColor
        cell.imgVwProfile.clipsToBounds = true
        
     return cell
    }}
let imageCatch = NSCache<AnyObject, AnyObject>()
extension UIImageView {
    func loadn(url: URL) {
        image = nil
        if let imageFromCatch = imageCatch.object(forKey: URL.self as AnyObject) as? UIImage {
        self.image = imageFromCatch
        return
    }
    DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    imageCatch.setObject(image, forKey: URL.self as AnyObject)
                    
                    DispatchQueue.main.async {
                        self?.image = image
                    }}}}}}

//dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//
//    // Download image
//
//    dispatch_async(dispatch_get_main_queue(), ^{
//
//        // UIImageView resizing
//        });
//    });


//{
//    "response": {
//        "message": "success",
//        "status": "1",
//        "total_records": "12",
//        "last_page": "2",
//        "data": {
//            "followers": "12",
//            "following": "24",
//            "detail": [
//            {
//            "user_id": "2",
//            "username": "akshay",
//            "fullname": "akshay",
//            "profile_pic": "https://rawuncensored.com/uploads/profile/img_1926424850.jpg",
//            "users_type": "2"
//           },
//DispatchQueue.global(qos: .userInitiated).async { [weak self] in
//    guard let self = self else {
//        return
//    }
//    let overlayImage = self.imgVwProfile(self.image)
//
//    // 2
//    DispatchQueue.main.async { [weak self] in
//        // 3
//        self?.fadeInNewImage(overlayImage)
//    }
//}
