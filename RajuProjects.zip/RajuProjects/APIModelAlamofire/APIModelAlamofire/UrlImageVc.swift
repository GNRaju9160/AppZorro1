
import UIKit

class UrlImageVc: UIViewController {
    @IBOutlet weak var imgVw: UIImageView!
    
    let imgUrl = URL(string: "https://www.gstatic.com/webp/gallery3/2.png")!
   
    override func viewDidLoad() {
        super.viewDidLoad()
      downloadImage(with: imgUrl)
    }
    func downloadImage(with url: URL) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.imgVw.image = UIImage(data: data!)
            }
        }.resume()
    }}
