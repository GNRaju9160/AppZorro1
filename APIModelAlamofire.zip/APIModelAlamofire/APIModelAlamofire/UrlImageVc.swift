
import UIKit



class UrlImageVc: UIViewController {
   
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var btnDataPass: UIButton!
    @IBOutlet weak var lblText: UILabel!
    
    let imgUrl = URL(string: "https://www.gstatic.com/webp/gallery3/2.png")!
    
    var selectedImage = UIImage()
    var selectData = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgVw.image = selectedImage
       lblText.text = selectData
        
      downloadImage(with: imgUrl)
   
    }
    func downloadImage(with url: URL) {
        URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.imgVw.image = UIImage(data: data!)
            }
        }.resume()
    }
//    func showData(data: String) {
//        self.lblText.text = data
//    }
//
    
   
    @IBAction func btnAct(_ sender: Any) {
       
       let nextVC = storyboard?.instantiateViewController(identifier: "ApiGetDataVC") as! ApiGetDataVC
        let nextVC = storyboard!.instantiateViewController(withIdentifier: "ApiGetDataVC") as! ApiGetDataVC
        self.navigationController?.pushViewController(nextVC, animated: true)
 
}
}
