
import UIKit
//protocol ApiVcDatatrans {
//    func showData(detail: ModelData)
//}
// ,ApiVcDatatrans
class UrlImageVc: UIViewController {
    //    func showData(detail: ModelData) {
    //        //  lblText.text = "\(detail.fullName)\n\(detail.userType)"
    //        btnDataPass.setTitle(detail.fullName, for: UIControl.State.normal )
    //        downloadImage(detail.profilepic)
    //    }
    
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var btnDataPass: UIButton!
    @IBOutlet weak var lblText: UILabel!
    
    //  let imgUrl = URL(string: "https://www.gstatic.com/webp/gallery3/2.png")!
    
    var selectedImage = UIImage()
    var selectData = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgVw.image = selectedImage
        //   lblText.text = selectData
        
        downloadImage("https://www.gstatic.com/webp/gallery3/2.png")
   
        
        // NotificationCenter method
                NotificationCenter.default.addObserver(self, selector: #selector(notificationFired(_ :)), name: NSNotification.Name("ModelData"), object: nil)
            }
                @objc func notificationFired (_ notification: Notification) {
                let userInfo = notification.userInfo
                    if let data = userInfo as? [String: Any] {
                     lblText.text = "\(data["name"] ?? "")\n\(data["userId"] ?? "")"
                    downloadImage(data["photo"] as! String)
                    }
    }
    
    func downloadImage(_ urlStr:String) {
        URLSession.shared.dataTask(with: URL(string: urlStr)!) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.imgVw.image = UIImage(data: data!)
            }
            }.resume()
    }
    
    @IBAction func btnAct(_ sender: Any) {
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "ApiGetDataVC") as! ApiGetDataVC
        //  nextVC.delegateToDataTrans = self
     //     nextVC.completionHandler = { text in
            self.navigationController?.pushViewController(nextVC, animated: true)
    //    }
    }
}
