
import UIKit

protocol transferToFirstVC {
    func shareData(detail:ModelData)    
}

class UrlImageVc: UIViewController, transferToFirstVC {
    func shareData(detail: ModelData) {
        lblText.text = "\(detail.fullName)\n\(detail.userName)"
        downloadImage(detail.profilepic)
    }
    
    @IBOutlet weak var imgVw: UIImageView!
    @IBOutlet weak var btnDataPass: UIButton!
    @IBOutlet weak var lblText: UILabel!
    
    var selectedImage = UIImage()
    var selectData = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgVw.image = selectedImage
        lblText.text = selectData
//        downloadImage("")
    }
    
    func downloadImage(_ urlStr:String) {
        URLSession.shared.dataTask(with: URL(string: urlStr)!) { (data, response, error) in
            if error != nil {
                print(error!)
                return
            }
            DispatchQueue.main.async {
                self.imgVw.image = UIImage(data: data!)
            }
            }.resume()
    }
    
    
    @IBAction func btnAct(_ sender: Any) {
        
        let nextVC = storyboard?.instantiateViewController(withIdentifier: "ApiGetDataVC") as! ApiGetDataVC
        nextVC.delegateToTransfer = self
        self.navigationController?.pushViewController(nextVC, animated: true)
        
    }
}
