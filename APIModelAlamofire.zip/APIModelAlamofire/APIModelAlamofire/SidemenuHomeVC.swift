//
//  SidemenuHomeVC.swift
//  APIModelAlamofire
//
//  Created by Appzorro on 13/01/20.
//  Copyright © 2020 Appzorro. All rights reserved.
//

import UIKit

class SidemenuHomeVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

}
