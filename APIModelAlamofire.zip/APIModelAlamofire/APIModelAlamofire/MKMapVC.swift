
import UIKit
import MapKit
import CoreLocation
class MKMapVC: UIViewController {
    @IBOutlet weak var mkMap: MKMapView!
  
    let locationManager : CLLocationManager = CLLocationManager ()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.distanceFilter = kCLDistanceFilterNone
            locationManager.startUpdatingLocation()
          //mkMap.showsUserLocation = true
    }
        }
extension MKMapVC: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last! as CLLocation
        let currentLocation = location.coordinate
        let coordinateRegion = MKCoordinateRegion(center: currentLocation, latitudinalMeters: 800, longitudinalMeters: 800)
        
     //   mkmap.setRegion(coordinateRegion, animated: true)
     //    locationManager.stopUpdatingLocation()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
}
    func locationManager(manager: CLLocationManager!, didChangeAuthorizationStatus status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            // If status has not yet been determied, ask for authorization
            manager.requestWhenInUseAuthorization()
            break
        case .authorizedWhenInUse:
            // If authorized when in use
            manager.startUpdatingLocation()
            break
        case .authorizedAlways:
            // If always authorized
            manager.startUpdatingLocation()
            break
        case .restricted:
            // If restricted by e.g. parental controls. User can't enable Location Services
            break
        case .denied:
            // If user denied your app access to Location Services, but can grant access from Settings.app
            break
        default:
            break
        }
    }
}


//func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//    let myCoord = locations[locations.count - 1]
//    self. = myCoord
//
//    // get lat and long
//    let myLat = myCoord.coordinate.latitude
//    let myLong = myCoord.coordinate.longitude
//    let myCoord2D = CLLocationCoordinate2D(latitude: myLat, longitude: myLong)
//
//
//    //create MKCoordinateSpan for the span of the map
//    let myLatDelta = 0.05 //rate of zoom in the mapView
//    let myLongDelta = 0.05
//    let mySpan = MKCoordinateSpan(latitudeDelta: myLatDelta, longitudeDelta: myLongDelta)
//
//    //set region using the 2D coordinates and the Span.
//    let myRegion = MKCoordinateRegion(center: myCoord2D, span: mySpan)
//
//    //center map at this region
//    mkMap.setRegion(myRegion, animated: true) //instance of mapView created outside the function
//}
//
//setUpMapView()
//}
//func setUpMapView() {
//    mkMap.showsUserLocation = true
//    mkMap.showsCompass = true
//    mkMap.showsScale = true
//    currentLocation()
//
//}
//func currentLocation() {
//    locationManager.delegate = self
//    locationManager.desiredAccuracy = kCLLocationAccuracyBest
//    if #available(iOS 11.0, *) {
//        locationManager.showsBackgroundLocationIndicator = true
//    } else {
//        // Fallback on earlier versions
//    }
//    locationManager.startUpdatingLocation()
//}
//
//}

//    }
    //     locationManager.requestWhenInUseAuthorization()
    //    locationManager.desiredAccuracy = kCLLocationAccuracyBest
    //    locationManager.distanceFilter = kCLDistanceFilterNone
    //    locationManager.startUpdatingLocation()
    //  mkMap.showsUserLocation = true
    //
    //
    //        locationManager.desiredAccuracy = kCLLocationAccuracyBest
    //        if #available(iOS 8.0, *) {
    //            locationManager.requestAlwaysAuthorization()
    //        } else {
    //            // Fallback on earlier versions
    //        }
    //        locationManager.startUpdatingLocation()
    //
    //        // add gesture recognizer
    //        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(MKMapVC.mapLongPress(_:))) // colon needs to pass through info
    //        longPress.minimumPressDuration = 1.5 // in seconds
    //        //add gesture recognition
    //        mkMap.addGestureRecognizer(longPress)
 // }
//
//    // func called when gesture recognizer detects a long press
//
//    @objc func mapLongPress(_ recognizer: UIGestureRecognizer) {
//
//        print("A long press has been detected.")
//
//        let touchedAt = recognizer.location(in: self.mkMap) // adds the location on the view it was pressed
//        let touchedAtCoordinate : CLLocationCoordinate2D = mkMap.convert(touchedAt, toCoordinateFrom: self.mkMap) // will get coordinates
//
//        let newPin = MKPointAnnotation()
//        newPin.coordinate = touchedAtCoordinate
//        mkMap.addAnnotation(newPin)
//
//
//    }
//    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
//        mkMap.removeAnnotation(newPin)
//
//        let location = locations.last! as CLLocation
//
//        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
//        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
//
//        //set region on the map
//        mkMap.setRegion(region, animated: true)
//
//        newPin.coordinate = location.coordinate
//        mkMap.addAnnotation(newPin)
//
//    }
//
//       let sourcelocation = CLLocationCoordinate2D(latitude: track.lattitude, longitude: twalk.lon)
//        let destinationLocation = CLLocationCoordinate2D(latitude: twalk.lat, longitude: twalk.lon)
//self.locationManager.requestAlwaysAuthorization()
//self.locationManager.requestWhenInUseAuthorization()
//
//if CLLocationManager.locationServicesEnabled() {
//    locationManager.delegate = self
//    locationManager.desiredAccuracy = kCLLocationAccuracyBest
//    locationManager.startUpdatingLocation()
//}
