
import UIKit
import MapKit
import CoreLocation

class SearchMapKitVC: UIViewController {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    var currentCoordinate : CLLocationCoordinate2D!
    
    override func viewDidLoad() {
        super.viewDidLoad()
locationManager.requestAlwaysAuthorization()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
        locationManager.startUpdatingLocation()
        
        }
    }
    extension SearchMapKitVC: CLLocationManagerDelegate {
        func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
           manager.stopUpdatingLocation()
            guard let currentLocation = locations.first else { return }
            currentCoordinate = currentLocation.coordinate
            mapView.userTrackingMode = .followWithHeading
            
        }
    }
extension SearchMapKitVC: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
   searchBar.endEditing(true)
        let geoCoder = CLGeocoder()
        geoCoder.geocodeAddressString(searchBar.text!) { (placemarks:[CLPlacemark]?, error:Error?) in
            if error == nil {
                let placemark = placemarks?.first
                let annotation = MKPointAnnotation()
              annotation.coordinate = (placemark?.location?.coordinate)!
                annotation.title = self.searchBar.text!
                
                self.mapView.addAnnotation(annotation)
                self.mapView.selectAnnotation(annotation, animated: true)
            }else{
                print(error?.localizedDescription ?? "error")
            }
        }
    }
}
//extension SearchMapKitVC: MKMapViewDelegate {
//    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
//        return MKOverlayRenderer()
//    }
//}
