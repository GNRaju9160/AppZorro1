
import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tblVw: UITableView!
    var arrDetails = [Details]()
    let urlStr = "https://rawuncensored.com/api.php"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myApi()
    }
    func myApi() {
        let parameters: Parameters = ["action": "get_noti", "user_id": "12 ", "pageNo": "1"]
        Alamofire.request(urlStr, method: .get, parameters: parameters).responseJSON { response in
            if var resp = response.result.value as? [String : Any],var respData = resp["response"] as? [String: Any],let data = respData["data"] as? [[String: Any]]{
                for i in data {
                    let datar = Details(i)
                    self.arrDetails.append(datar)
                }
                DispatchQueue.main.async {
                    self.tblVw.reloadData()
                }}}}}
extension ViewController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDetails.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "APITvc") as! APITvc
        let data : Details
        data = arrDetails[indexPath.row]
        cell.lblUserName.text = data.username
        cell.lblNotification.text = data.notification
        if let imgUrl = URL(string:data.profile_pic){
        cell.imgProfile.load(url:imgUrl)//.image = data.profile_pic
        }
        cell.imgProfile.layer.borderWidth = 1.0
        cell.imgProfile.layer.borderColor = UIColor.red.cgColor
        cell.imgProfile.clipsToBounds = true
        return cell
    }}
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }}}}}}
//if let imgUrl = URL(string:data.profile_pic){
//    cell.imgProfile.load(url:imgUrl)//.image = data.profile_pic
//}


//DispatchQueue.main.async {
//    self.tblVw.reloadData()
//return cell
//{
//    "response": {
//        "message": "success",
//        "status": "1",
//        "total_records": "31",
//        "last_page": "3",
//        "data": [
//        {
//        "post_id": "0",
//        "notification": "started following you",
//        "profile_pic": "https://rawuncensored.com/uploads/profile/img_1642086467.jpg",
//        "caption": "",
//        "user_id": "109",
//        "username": "erickaantonofficial"
//        },

//}
//  http://www.javascriptkit.com/dhtmltutors/javascriptkit.json
//   var imgurl = data["profile_pic"] as? [[String: Any]]
//    func downloadImage(with url : URL){
//        URLSession.shared.dataTask(with: url) { (data, response, error) in
//
//            if error != nil {
//            return
//        }
//        DispatchQueue.main.sync {
//            self.tblVw.reloadData()
//        }
//        }}}
