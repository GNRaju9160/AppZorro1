//
//  SidemenuListVC.swift
//  APIModelAlamofire
//
//  Created by Appzorro on 13/01/20.
//  Copyright © 2020 Appzorro. All rights reserved.
//

import UIKit

@available(iOS 13.0, *)
@available(iOS 13.0, *)
class SidemenuListVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    @IBOutlet weak var imgVw: UIImageView!
 //    let picker = UIImagePickerController()
    override func viewDidLoad() {
        super.viewDidLoad()

       imgVw.layer.borderWidth = 1.0
        imgVw.clipsToBounds = true
 //       picker.delegate = self
    }

    @IBAction func btnHome(_ sender: UIButton) {
    let vc = storyboard?.instantiateViewController(identifier: "SidemenuHomeVC") as! SidemenuHomeVC
       self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func btnInbox(_ sender: UIButton) {
        let vc2 = storyboard?.instantiateViewController(identifier: "SidemenuInboxVC") as! SidemenuInboxVC
        self.navigationController?.pushViewController(vc2, animated: true)
    
    }
    
    @IBAction func btnCamer(_ sender: Any) {
        var mypickerController = UIImagePickerController()
        mypickerController.delegate = self
        mypickerController.sourceType = UIImagePickerController.SourceType.photoLibrary
        
        self.present(mypickerController, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        imgVw.image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
    }
        
    }
    

