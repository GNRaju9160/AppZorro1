
import Foundation
class ModelData {
    var use_Id = String()
    var userName = String()
    var fullName = String()
    var userType = String()
    var profilepic = String()
    
    
    init(_ data :[String: Any]) {
        
        use_Id = data["user_id"] as? String ?? "No Data"
        userName = data["username"] as? String ?? "No Data"
        fullName = data["fullname"] as? String ?? "No Data"
        userType = data["users_type"] as? String ?? "No Data"
        profilepic = data["profile_pic"]as? String ?? ""
    }
}

